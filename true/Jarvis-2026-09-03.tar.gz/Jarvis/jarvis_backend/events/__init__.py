"""Event system package."""
