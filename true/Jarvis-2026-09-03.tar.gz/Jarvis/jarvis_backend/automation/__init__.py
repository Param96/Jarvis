"""Automation integration package."""
