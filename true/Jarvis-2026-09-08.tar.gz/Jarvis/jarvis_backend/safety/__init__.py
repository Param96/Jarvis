"""Safety package."""
