"""Application assembly package."""
